<?php
return array(
	//'配置项'=>'配置值'
	'url_model' => '0',
	'html_cache_on' => false,
);
?>