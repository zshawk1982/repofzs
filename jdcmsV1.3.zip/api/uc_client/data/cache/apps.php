<?php
$_CACHE['apps'] = array (
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'cs',
    'url' => 'http://localhost/cs',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/cs/ucenter',
);
